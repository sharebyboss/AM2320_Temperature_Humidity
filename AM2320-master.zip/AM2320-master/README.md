Arduino - AM2320
=================
Library for working with the temperature and humidity sensor AM2320.

The AM2320 sensor is connected via the I2C bus (Wire).

![AM2320_pins](https://github.com/EngDial/AM2320/blob/master/AM2320_pins.jpg)
